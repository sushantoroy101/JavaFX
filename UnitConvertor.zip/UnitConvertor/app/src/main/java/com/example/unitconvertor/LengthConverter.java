package com.example.unitconvertor;

public class LengthConverter {

    public static Double Meter_to_centimeter(Double m){
        return m*100;
    }
    public static Double Meter_to_milimeter(Double m){
        return m*1000;
    }
    public static Double Meter_to_kilometer(Double m){
        return m/1000;
    }
}
