package com.example.unitconvertor;

public class convertCurrency {
    public static Double usdToBdt(Double d){
        return d*84;
    }
    public static Double bdtToUsd(Double d){
        return d/84;
    }
    public static Double bdtToInd(Double d){
        return d*1.19;
    }
}
