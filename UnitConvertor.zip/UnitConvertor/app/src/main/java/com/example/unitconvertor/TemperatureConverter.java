package com.example.unitconvertor;

public class TemperatureConverter {

    public static Double cels_to_kalv(Double cels){
        return cels+273.15;
    }
    public static Double kalv_to_cels(Double kalv){
        return kalv-273.15;
    }

    public static Double cens_to_Farh(Double cels){
        return (9*cels+160)/5;
    }
    public static Double Farh_to_cels(Double Farh){
        return ((Farh-32)/9)*5;
    }
    public static Double Farh_to_kalv(Double Farh){
        return (((Farh-32)/9)*5)+273.15;
    }
    public static Double Kalv_to_Farh(Double kalv){
        return (9*((kalv-273.15)/5))+32;
    }

}
