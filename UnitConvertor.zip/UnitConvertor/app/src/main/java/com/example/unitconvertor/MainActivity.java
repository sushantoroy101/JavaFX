package com.example.unitconvertor;



import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    RadioGroup rdg1,rdg2,rdg3,rdg4;
    private Button sub,clr;
    private RadioButton currency,length,temperature;
    private RadioButton bdtousd,usdtobdt,bdttoind;
    private RadioButton t1,t2,t3,t4,t5,t6;
    private RadioButton l1,l2,l3;
    private EditText edttxt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        currency=findViewById(R.id.currency);
        length=findViewById(R.id.length);
        temperature=findViewById(R.id.temperature);
        edttxt=findViewById(R.id.edittxt);
        usdtobdt=findViewById(R.id.rd1);
        bdtousd=findViewById(R.id.rd2);
        bdttoind=findViewById(R.id.rd3);
        sub=findViewById(R.id.submit);
        clr=findViewById(R.id.clr);
        rdg1=findViewById(R.id.rdg1);
        rdg2=findViewById(R.id.rdg2);
        rdg3=findViewById(R.id.rdg3);
        rdg4=findViewById(R.id.rdg4);
        t1=findViewById(R.id.t1);
        t2=findViewById(R.id.t2);
        t3=findViewById(R.id.t3);
        t4=findViewById(R.id.t4);
        t5=findViewById(R.id.t5);
        t6=findViewById(R.id.t6);
        l1=findViewById(R.id.l1);
        l2=findViewById(R.id.l2);
        l3=findViewById(R.id.l3);

//Currency
        currency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                length.setVisibility(View.GONE);
                temperature.setVisibility(View.GONE);
                rdg2.setVisibility(View.VISIBLE);
                sub.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String value=new String();
                        value=edttxt.getText().toString();
                        Double d;
                        d=Double.parseDouble(value);
                        Double res=new Double(d);
                        if (usdtobdt.isChecked()){
                            res=convertCurrency.usdToBdt(d);
                        }
                        else if (bdtousd.isChecked()){
                            res=convertCurrency.bdtToUsd(d);
                        }
                        else if (bdttoind.isChecked()){
                            res=convertCurrency.bdtToInd(d);
                        }
                        edttxt.setText(res.toString());


                    }
                });

            }
        });

//        Temperature

        temperature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                length.setVisibility(View.GONE);
                currency.setVisibility(View.GONE);
                rdg3.setVisibility(View.VISIBLE);
                sub.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String value=new String();
                        value=edttxt.getText().toString();
                        Double d;
                        d=Double.parseDouble(value);
                        Double res=new Double(d);
                        if (t1.isChecked()){
                            res=TemperatureConverter.cels_to_kalv(d);
                        }
                        else if (t2.isChecked()){
                            res=TemperatureConverter.kalv_to_cels(d);
                        }
                        else if (t3.isChecked()){
                            res=TemperatureConverter.cens_to_Farh(d);
                        }
                        else if (t4.isChecked()){
                            res=TemperatureConverter.Farh_to_cels(d);
                        }
                        else if (t5.isChecked()){
                            res=TemperatureConverter.Farh_to_kalv(d);
                        }
                        else if (t6.isChecked()){
                            res=TemperatureConverter.Kalv_to_Farh(d);
                        }

                        edttxt.setText(res.toString());


                    }
                });

            }
        });
        //Length
        length.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currency.setVisibility(View.GONE);
                temperature.setVisibility(View.GONE);
                rdg4.setVisibility(View.VISIBLE);
                sub.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String value=new String();
                        value=edttxt.getText().toString();
                        Double d;
                        d=Double.parseDouble(value);
                        Double res=new Double(d);
                        if (l1.isChecked()){
                            res=LengthConverter.Meter_to_centimeter(d);
                        }
                        else if (l2.isChecked()){
                            res=LengthConverter.Meter_to_milimeter(d);
                        }
                        else if (l3.isChecked()){
                            res=LengthConverter.Meter_to_kilometer(d);
                        }
                        edttxt.setText(res.toString());


                    }
                });

            }
        });

        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edttxt.setText("");
                rdg1.clearCheck();
                currency.setVisibility(View.VISIBLE);
                length.setVisibility(View.VISIBLE);
                temperature.setVisibility(View.VISIBLE);
                rdg2.setVisibility(View.GONE);
                rdg3.setVisibility(View.GONE);
                rdg4.setVisibility(View.GONE);
            }
        });
    }
}

